Home Exercise 2                            ==========================================================
CREATED BY : ABDALLAH NATSHEH ,  ID : 319076618.

Program description:
In "Home Exercise 2" we have a linux shell that works like the terminal in linux but it doesnt support all the commands

Ex2 this file contain all the code to run the shell

Program files: 
Ex2.c : source code of ex2

Compile and running: 
In terminal
compile :gcc ex2.c -o ex2 
run : ./ex2 

Input: 
Ex2 : the supported linux shell command in this program 
Output:
Ex2 :Num of command that used in the progarm and the total length of all the commands and the Average length of all commands. 
	
