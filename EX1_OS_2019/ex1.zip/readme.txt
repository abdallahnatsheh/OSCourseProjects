Home Exercise 1                            ==========================================================
CREATED BY : ABDALLAH NATSHEH ,  ID : 319076618.

Program description:
In "Home Exercise 1" we have a linux shell that works like the terminal in linux but it doesnt support all the commands

Ex1 this file contain all the code to run the shell

Program files: 
Ex1.c : source code of ex1

Compile and running: 
In terminal
compile :gcc ex1.c -o ex1 
run : ./ex1 

Input: 
Ex1 : the supported linux shell command in this program 
Output:
Ex1 :Num of command that used in the progarm and the total length of all the commands and the Average length of all commands. 
	
